﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TaskManagementApp.Models
{
    public enum Priority
    {
        Low,
        Medium,
        High
    }

    public enum Status
    {
        ToDo,
        InProgress,
        Completed
    }

    public class Task
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Task Name")]
        public string TaskName { get; set; }

        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Due Date")]
        public DateTime DueDate { get; set; }

        [Required]
        public Priority Priority { get; set; }

        [Required]
        public Status Status { get; set; }

        public string UserId { get; set; }
        public ApplicationUser User { get; set; }

        
        //public int? AssignedUserId { get; set; }

        
        //public User AssignedUser { get; set; }
        [Display(Name = "Assigned UserId")]
        public string AssignedUserId { get; set; }  // This matches ApplicationUser's Id type
        [Display(Name = "Assigned User")]
        public ApplicationUser AssignedUser { get; set; }  // Navigation property
    }
}
