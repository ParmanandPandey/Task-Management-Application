﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManagementApp.Models;
using TaskManagementApp.Services;

namespace TaskManagementApp.Controllers
{
    
    public class TasksController : Controller
    {
        private readonly ITaskService _taskService;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<TasksController> _logger;

        public TasksController(UserManager<ApplicationUser> userManager, ITaskService taskService, ILogger<TasksController> logger)
        {
            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
            _taskService = taskService ?? throw new ArgumentNullException(nameof(taskService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<IActionResult> Index(string priorityFilter, string statusFilter)
        {
            try
            {
                var tasks = await _taskService.GetTasksAsync();

                // Convert string filters to enums
                Priority? priorityEnum = null;
                if (Enum.TryParse(priorityFilter, out Priority parsedPriority))
                {
                    priorityEnum = parsedPriority;
                }

                Status? statusEnum = null;
                if (Enum.TryParse(statusFilter, out Status parsedStatus))
                {
                    statusEnum = parsedStatus;
                }

                if (priorityEnum.HasValue)
                {
                    tasks = tasks.Where(t => t.Priority == priorityEnum.Value).ToList();
                }

                if (statusEnum.HasValue)
                {
                    tasks = tasks.Where(t => t.Status == statusEnum.Value).ToList();
                }

                return View(tasks);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving tasks.");
                return View("Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> MarkAsCompleted(int id)
        {
            try
            {
                await _taskService.MarkTaskAsCompletedAsync(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error marking task with ID {id} as completed.");
                return View("Error");
            }
        }

        // task form
        public IActionResult Create()
        {

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Models.Task task)
        {
            if (!ModelState.IsValid)
            {
                return View(task);
            }

            try
            {
                if (_userManager == null)
                {
                    _logger.LogError("UserManager is null.");
                    throw new InvalidOperationException("UserManager is not initialized.");
                }

                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    _logger.LogError("User is null.");
                    throw new InvalidOperationException("User is not found.");
                }

                task.UserId = user.Id;

                if (_taskService == null)
                {
                    _logger.LogError("TaskService is null.");
                    throw new InvalidOperationException("TaskService is not initialized.");
                }

                await _taskService.CreateTaskAsync(task);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating task.");
                ModelState.AddModelError("", "An error occurred while creating the task.");
                return View(task);
            }
        }

        // Edit task by ID
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var task = await _taskService.GetTaskAsync(id);
                if (task == null)
                {
                    return NotFound();
                }
                return View(task);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving task with ID {id}.");
                return View("Error");
            }
        }

        // Update task
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Models.Task task)
        {
            if (!ModelState.IsValid)
            {
                return View(task);
            }

            try
            {
                await _taskService.UpdateTaskAsync(task);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating task.");
                ModelState.AddModelError("", "An error occurred while updating the task.");
                return View(task);
            }
        }

        // GET: /Tasks/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var task = await _taskService.GetTaskAsync(id);
                if (task == null)
                {
                    return NotFound();
                }
                return View(task);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving task with ID {id}.");
                return View("Error");
            }
        }

        // Show the delete confirmation page
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var task = await _taskService.GetTaskAsync(id);
                if (task == null)
                {
                    return NotFound();
                }
                return View(task);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving task with ID {id}.");
                return View("Error");
            }
        }

        // Delete task
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await _taskService.DeleteTaskAsync(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting task.");
                // Optionally, show a user-friendly error message
                return View("Error");
            }
        }
    }
}

