﻿# Task Management Application

## Overview
This Task Management Application allows users to create, assign, manage, and complete tasks. 
It includes user authentication and role-based task assignment using ASP.NET Core Identity.

## Prerequisites
- [.NET 5 SDK](https://dotnet.microsoft.com/download/dotnet/5.0)
- SQL Server
- Entity Framework Core

## Setup Instructions
1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd TaskManagementApp


## Description
A simple task management application built using ASP.NET Core MVC.

## Features
- User Authentication using ASP.NET Core Identity
- Task Search functionality
- Task Assignment with user relationships
- Clean code with Repository Pattern, Dependency Injection, etc.

## Setup Instructions
1. Clone the repository.
2. Open the solution in Visual Studio.
3. Run `dotnet restore` to install dependencies.
4. Apply migrations: `dotnet ef database update`.
5. Run the application: `dotnet run`.

## Database Setup
- Ensure SQL Server is running.
- Update the connection string in `appsettings.json` as required.
