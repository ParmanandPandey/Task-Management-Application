﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskManagementApp.Services
{
    public interface ITaskService
    {
        Task<IEnumerable<Models.Task>> GetTasksAsync();
        Task<Models.Task> GetTaskAsync(int id);
        Task CreateTaskAsync(Models.Task task);
        Task UpdateTaskAsync(Models.Task task);
        Task DeleteTaskAsync(int id);
        Task MarkTaskAsCompletedAsync(int id);
    }
}
