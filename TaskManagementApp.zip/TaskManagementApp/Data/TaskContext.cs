﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManagementApp.Models;
using Task = TaskManagementApp.Models.Task;

namespace TaskManagementApp.Data
{
    //public class TaskContext: DbContext
    //{
    //    public TaskContext(DbContextOptions<TaskContext> options) : base(options) { }

    //    public DbSet<Models.Task> Tasks { get; set; }
    //    public DbSet<User> Users { get; set; } // For bonus feature
    //}

    public class TaskContext : IdentityDbContext<ApplicationUser>
    {
        public TaskContext(DbContextOptions<TaskContext> options) : base(options)
        {
        }

        public DbSet<Models.Task> Tasks { get; set; }
        //public DbSet<User> Userss { get; set; }
        public DbSet<ApplicationUser> Users { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Define the relationship between Task and User
            modelBuilder.Entity<Task>()
                .HasOne(t => t.AssignedUser)  // The user the task is assigned to
                .WithMany(u => u.Tasks)       // A user can have many tasks
                .HasForeignKey(t => t.AssignedUserId)  // Specify the foreign key
                .OnDelete(DeleteBehavior.Restrict);   // Prevent cascade delete if necessary
        }
        //public DbSet<User> Users { get; set; }
    }
}
